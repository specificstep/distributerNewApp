package specific.com.GlobalClasses;

/**
 * Created by programmer044 on 03/03/17.
 */

public interface DrawerLocker {
    public void setDrawerEnabled(boolean enabled);
}
