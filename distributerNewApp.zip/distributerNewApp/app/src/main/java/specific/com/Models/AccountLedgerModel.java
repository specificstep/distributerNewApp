package specific.com.Models;

/**
 * Created by ubuntu on 16/3/17.
 */

public class AccountLedgerModel {
    public String created_date;
    public String type;
    public String payment_id;
    public String particular;
    public String cr_dr;
    public String amount;
    public String balance;
}
