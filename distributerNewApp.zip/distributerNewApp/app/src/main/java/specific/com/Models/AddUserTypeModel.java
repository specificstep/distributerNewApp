package specific.com.Models;

public class AddUserTypeModel {

    public String AddUserId;
    public String AddUserName;

    public AddUserTypeModel() {
    }

    public String getAddUserId() {
        return AddUserId;
    }

    public void setAddUserId(String addUserId) {
        AddUserId = addUserId;
    }

    public String getAddUserName() {
        return AddUserName;
    }

    public void setAddUserName(String addUserName) {
        AddUserName = addUserName;
    }
}
