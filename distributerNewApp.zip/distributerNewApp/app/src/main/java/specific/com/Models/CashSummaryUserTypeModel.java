package specific.com.Models;

public class CashSummaryUserTypeModel {

    public String rid = "";
    public String role_name = "";

    public CashSummaryUserTypeModel() {
    }

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }

    public String getRole_name() {
        return role_name;
    }

    public void setRole_name(String role_name) {
        this.role_name = role_name;
    }
}
