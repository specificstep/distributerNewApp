package specific.com.Models;

/**
 * Created by ubuntu on 16/3/17.
 */

public class CashbookModel {
    public String paymentId;
    public String paymentFrom;
    public String paymentTo;
    public String userType;
    public String amount;
    public String balance;
    public String remarks;
    public String dateTime;
}
