package specific.com.Models;

/**
 * Created by ubuntu on 24/1/17.
 */

public class Color {
    String color_name;
    String colo_value;

    public String getColor_name() {
        return color_name;
    }

    public void setColor_name(String color_name) {
        this.color_name = color_name;
    }

    public String getColo_value() {
        return colo_value;
    }

    public void setColo_value(String colo_value) {
        this.colo_value = colo_value;
    }
}
