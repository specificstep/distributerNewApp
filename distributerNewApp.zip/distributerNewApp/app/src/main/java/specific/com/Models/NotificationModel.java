package specific.com.Models;

/**
 * Created by ubuntu on 14/3/17.
 */

public class NotificationModel {
    public String id;
    public String title;
    public String message;
    public String receiveDateTime;
    public String saveDateTime;
    public String readFlag;
    public String readDateTime;
//    public String deleteFlag;
}
