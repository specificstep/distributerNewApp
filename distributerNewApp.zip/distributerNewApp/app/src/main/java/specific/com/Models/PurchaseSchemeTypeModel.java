package specific.com.Models;

public class PurchaseSchemeTypeModel {

    public String purchaseTypeId;
    public String purchaseTypeName;

    public PurchaseSchemeTypeModel() {
    }

    public String getPurchaseTypeId() {
        return purchaseTypeId;
    }

    public void setPurchaseTypeId(String purchaseTypeId) {
        this.purchaseTypeId = purchaseTypeId;
    }

    public String getPurchaseTypeName() {
        return purchaseTypeName;
    }

    public void setPurchaseTypeName(String purchaseTypeName) {
        this.purchaseTypeName = purchaseTypeName;
    }
}
