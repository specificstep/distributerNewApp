package specific.com.Models;

/**
 * Created by ubuntu on 13/1/17.
 */

public class State {
    String circle_id;
    String circle_name;

    public String getCircle_id() {
        return circle_id;
    }

    public void setCircle_id(String circle_id) {
        this.circle_id = circle_id;
    }

    public String getCircle_name() {
        return circle_name;
    }

    public void setCircle_name(String circle_name) {
        this.circle_name = circle_name;
    }
}
