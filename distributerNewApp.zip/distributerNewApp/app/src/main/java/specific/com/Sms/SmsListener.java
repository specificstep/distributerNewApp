package specific.com.Sms;

/**
 * Created by programmer044 on 20/02/17.
 */

public interface SmsListener {
    public void messageReceived(String messageText);
}
