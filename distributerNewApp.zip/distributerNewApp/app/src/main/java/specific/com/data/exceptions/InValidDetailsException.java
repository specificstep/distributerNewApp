package specific.com.data.exceptions;

public class InValidDetailsException extends Exception {
    public InValidDetailsException(String message) {
    }
}
