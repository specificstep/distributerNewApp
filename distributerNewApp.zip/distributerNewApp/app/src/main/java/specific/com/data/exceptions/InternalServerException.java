package specific.com.data.exceptions;

public class InternalServerException extends Exception {

    public InternalServerException() {
    }
}
