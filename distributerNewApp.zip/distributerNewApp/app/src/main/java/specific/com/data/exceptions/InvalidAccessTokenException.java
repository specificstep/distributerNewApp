package specific.com.data.exceptions;

public class InvalidAccessTokenException extends Exception {

    public InvalidAccessTokenException(String message) {
        super(message);
    }
}
