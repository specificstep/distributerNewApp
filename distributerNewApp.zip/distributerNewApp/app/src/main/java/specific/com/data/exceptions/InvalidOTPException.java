package specific.com.data.exceptions;

public class InvalidOTPException extends Exception {

    public InvalidOTPException(String message) {
        super(message);
    }
}
