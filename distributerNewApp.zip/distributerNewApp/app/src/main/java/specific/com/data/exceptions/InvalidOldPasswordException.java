package specific.com.data.exceptions;

public class InvalidOldPasswordException extends Exception {

    public InvalidOldPasswordException(String message) {
        super(message);
    }
}
