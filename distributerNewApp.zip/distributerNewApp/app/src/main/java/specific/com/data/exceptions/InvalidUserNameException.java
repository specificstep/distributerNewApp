package specific.com.data.exceptions;

public class InvalidUserNameException extends Exception {

    public InvalidUserNameException(String message) {
        super(message);
    }
}
