package specific.com.data.exceptions;


public class NetworkConnectionException extends Exception {

    public NetworkConnectionException(String message) {
        super(message);
    }

    public NetworkConnectionException() {

    }
}
