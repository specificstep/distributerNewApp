package specific.com.data.exceptions;

public class RechargeFailedException extends Exception {
    public RechargeFailedException(String message) {
        super(message);
    }
}
