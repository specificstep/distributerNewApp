package specific.com.data.exceptions;

public class SignInException extends Exception {

    public SignInException(String message) {
        super(message);
    }
}
