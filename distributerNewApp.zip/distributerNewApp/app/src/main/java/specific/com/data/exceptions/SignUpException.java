package specific.com.data.exceptions;

public class SignUpException extends Exception {

    public SignUpException(String message) {
        super(message);
    }
}
