package specific.com.ui.firebase;

import com.google.firebase.iid.FirebaseInstanceIdService;

/**
 * Created by ubuntu on 6/2/17.
 */

public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {

    private static final String TAG = "MyFirebaseIIDService";
//    String refreshedToken;
//    @Inject
//    Pref pref;

    @Override
    public void onCreate() {
        super.onCreate();
//        DaggerFirebaseComponent.builder()
//                .applicationComponent((ApplicationComponent) getApplicationContext())
//                .build()
//                .inject(this);
    }

    @Override
    public void onTokenRefresh() {

//        //Getting registration token
//
//        refreshedToken = FirebaseInstanceId.getInstance().getToken();
//        if (refreshedToken == null) {
//            refreshedToken = FirebaseInstanceId.getInstance().getToken();
//        }
//
//        pref.setValue(KEY_GCM_TOKEN, refreshedToken);
//        Log.i(TAG, "onTokenRefreshed : " + refreshedToken);
    }
}
